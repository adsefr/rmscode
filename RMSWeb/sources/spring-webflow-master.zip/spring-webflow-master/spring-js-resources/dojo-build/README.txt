
This directory contains the custom build of Dojo that distributed with Spring JavaScript. 
See ../scripts/dojo/README.txt for details.
