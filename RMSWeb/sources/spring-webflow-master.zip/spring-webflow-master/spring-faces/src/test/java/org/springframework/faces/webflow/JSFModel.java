package org.springframework.faces.webflow;

public class JSFModel {
	String value;

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
