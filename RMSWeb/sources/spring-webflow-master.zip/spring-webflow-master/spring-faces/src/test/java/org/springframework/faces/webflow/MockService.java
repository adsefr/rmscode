package org.springframework.faces.webflow;

public interface MockService {

	public void doSomething(String arg);
}
