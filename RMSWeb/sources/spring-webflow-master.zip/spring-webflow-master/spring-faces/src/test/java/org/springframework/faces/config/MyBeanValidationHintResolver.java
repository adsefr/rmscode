package org.springframework.faces.config;

import org.springframework.webflow.validation.BeanValidationHintResolver;

public class MyBeanValidationHintResolver extends BeanValidationHintResolver {

}
