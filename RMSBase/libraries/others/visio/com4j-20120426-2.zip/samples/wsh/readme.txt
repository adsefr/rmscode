Sample that uses Windows Scripting Host. Explained in detail in the tutorial
(https://com4j.dev.java.net/tutorial.html)