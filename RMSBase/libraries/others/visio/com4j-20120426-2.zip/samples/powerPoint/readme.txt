Sample that automates Microsoft PowerPoint.
